<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once "init.php";
$error='';

$pesan = ""; // <-- untuk menampung pesan error/sukses
//redirect kalau user sudah login
if( isset($_SESSION['user']) ){
    header('location: login.php');
}

if (isset($_POST['submit'])) {
    $nama = $_POST['username'];
    $pass = $_POST['password']; 

    if (!empty(trim($nama)) && !empty(trim($pass))) {
        if (login_cek_nama($nama)) {
            if (cek_data($nama, $pass)) {
               header("Location: webpart2.php");
exit();

 // sangat penting agar redirect bekerja
            } else {
                $error = "Password salah.";
            }
        } else {
            $error = "Username belum terdaftar.";
        }
    } else {
        $error = "Nama dan password tidak boleh kosong.";
    }
}

require_once "header.php";

//menguji pesan session
 if(isset($_SESSION['msg'])) {
flash_delete($_SESSION['msg']);
 }
?>

<h2>Login</h2>
<?php if (!empty($pesan)) echo "<p style='color:red;'>$pesan</p>"; ?>

<form action="login.php" method="post">
    <label for="">Nama</label> <br>
    <input type="text" name="username"> <br> <br>

    <label for="">Password</label> <br>
    <input type="password" name="password"> <br> <br>

    <input type="submit" name="submit" value="login">
    <br>

    <?php if($error != '') { ?>
        <div id="error">
            <?php echo $error; ?>
        </div>
    <?php } ?>

</form>

<?php require_once "footer.php"; ?>

<?php

 